// empty file that doesn't inherit from text mode
