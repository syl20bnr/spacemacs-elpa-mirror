select mt.myVar
    || '-*-' myVarLabel,
       myVar2
from   myTable mt;

-- Local Variables:
-- mode: sql
-- mode: sqlind-minor
-- tab-width: 2
-- indent-tabs-mode: nil
-- sql-product: oracle
-- End:
